/*
 * Vencord, a Discord client mod
 * Copyright (c) 2026 X2 Salah and contributors
 * SPDX-License-Identifier: GPL-3.0-or-later
 */

import { app, BrowserWindow, IpcMainInvokeEvent, WebFrameMain, webFrameMain } from "electron";

const PLUGIN_NAME = "Quests Manager";

interface FrameRef {
    processId: number;
    routingId: number;
    applicationId: string | null;
}

const activityFrames: FrameRef[] = [];

function extractApplicationId(url: string): string | null {
    try {
        const parsed = new URL(url);
        const host = parsed.hostname;
        const suffix = ".discordsays.com";

        if (host.endsWith(suffix) && host !== "discordsays.com") {
            const appId = host.slice(0, -suffix.length);
            if (appId) return appId;
        }

        const fromQuery = parsed.searchParams.get("application_id")
            || parsed.searchParams.get("applicationId");
        if (fromQuery) return fromQuery;

        const pathMatch = parsed.pathname.match(/\/(\d{17,20})(?:\/|$)/);
        if (pathMatch) return pathMatch[1];
    } catch {
        return null;
    }

    return null;
}

function isActivityUrl(url: string): boolean {
    return url.includes("discordsays.com");
}

function frameMatchesApplicationId(frame: WebFrameMain, applicationId: string): boolean {
    const url = frame.url;
    if (!isActivityUrl(url)) return false;
    if (extractApplicationId(url) === applicationId) return true;
    return url.includes(applicationId);
}

function registerActivityFrame(frame: WebFrameMain): void {
    const url = frame.url;
    if (!isActivityUrl(url)) return;

    const { routingId, processId } = frame;
    const existing = activityFrames.find(
        ref => ref.processId === processId && ref.routingId === routingId
    );
    if (existing) {
        existing.applicationId = extractApplicationId(url);
        return;
    }

    cleanUpActivityFrames();
    activityFrames.push({
        processId,
        routingId,
        applicationId: extractApplicationId(url)
    });
}

function cleanUpActivityFrames(): WebFrameMain[] {
    const liveFrames: WebFrameMain[] = [];

    for (let i = activityFrames.length - 1; i >= 0; i--) {
        const { processId, routingId } = activityFrames[i];
        const frame = webFrameMain.fromId(processId, routingId);
        if (!frame) {
            activityFrames.splice(i, 1);
            continue;
        }
        liveFrames.push(frame);
    }

    return liveFrames;
}

function collectActivityFramesFromWindow(win: BrowserWindow): WebFrameMain[] {
    const found: WebFrameMain[] = [];

    try {
        for (const frame of win.webContents.mainFrame.framesInSubtree) {
            if (isActivityUrl(frame.url)) {
                registerActivityFrame(frame);
                found.push(frame);
            }
        }
    } catch (error) {
        console.error(`[${PLUGIN_NAME}] Failed to scan frames in window:`, error);
    }

    return found;
}

function scanAllWindowsForActivityFrames(): WebFrameMain[] {
    const found: WebFrameMain[] = [];

    for (const win of BrowserWindow.getAllWindows()) {
        found.push(...collectActivityFramesFromWindow(win));
    }

    return found;
}

const SDK_PROBE_JS = "!!(window.discordSDK && window.discordSDK.commands && typeof window.discordSDK.commands.questStartTimer === \"function\")";

function frameHasDiscordSdk(frame: WebFrameMain): boolean {
    try {
        return frame.executeJavaScript(SDK_PROBE_JS, true) === true;
    } catch {
        return false;
    }
}

function collectMatchingFrames(applicationId: string): WebFrameMain[] {
    const trimmedAppId = applicationId?.trim() || "";

    scanAllWindowsForActivityFrames();
    const frames = cleanUpActivityFrames();

    const matched: WebFrameMain[] = [];
    const seen = new Set<string>();

    const addFrame = (frame: WebFrameMain | null) => {
        if (!frame) return;
        const key = `${frame.processId}:${frame.routingId}`;
        if (seen.has(key)) return;
        seen.add(key);
        matched.push(frame);
    };

    if (trimmedAppId) {
        for (let i = activityFrames.length - 1; i >= 0; i--) {
            const ref = activityFrames[i];
            if (ref.applicationId === trimmedAppId) {
                addFrame(webFrameMain.fromId(ref.processId, ref.routingId));
            }
        }

        for (const frame of frames) {
            if (frameMatchesApplicationId(frame, trimmedAppId)) {
                addFrame(frame);
            }
        }
    } else {
        for (const frame of frames) addFrame(frame);
    }

    return matched;
}

function findMatchingFrame(applicationId: string): WebFrameMain | null {
    const matching = collectMatchingFrames(applicationId);
    if (matching.length === 0) return null;

    for (let i = matching.length - 1; i >= 0; i--) {
        if (frameHasDiscordSdk(matching[i])) return matching[i];
    }

    return matching[matching.length - 1];
}

function attachWindowListeners(win: BrowserWindow): void {
    collectActivityFramesFromWindow(win);

    win.webContents.on("did-frame-navigate", (_, __, ___, ____, _____, frameProcessId, frameRoutingId) => {
        const frame = webFrameMain.fromId(frameProcessId, frameRoutingId);
        if (frame) registerActivityFrame(frame);
    });

    win.webContents.on("did-frame-navigate-in-page", (_, __, ___, frameProcessId, frameRoutingId) => {
        const frame = webFrameMain.fromId(frameProcessId, frameRoutingId);
        if (frame) registerActivityFrame(frame);
    });

    win.webContents.on("frame-created", (_, { frame }) => {
        const onFrameReady = () => registerActivityFrame(frame);

        frame?.once("dom-ready", onFrameReady);
    });
}

for (const win of BrowserWindow.getAllWindows()) {
    attachWindowListeners(win);
}

app.on("browser-window-created", (_, win) => {
    attachWindowListeners(win);
});

export async function hasActivityFrame(_: IpcMainInvokeEvent, applicationId: string): Promise<boolean> {
    return findMatchingFrame(applicationId) != null;
}

export async function execInActivityFrame(
    _: IpcMainInvokeEvent,
    applicationId: string,
    jsCode: string
): Promise<string | null> {
    const frame = findMatchingFrame(applicationId);
    if (!frame) return null;

    try {
        const result = await frame.executeJavaScript(jsCode, true);
        if (result === undefined || result === null) return "null";
        return typeof result === "string" ? result : JSON.stringify(result);
    } catch (error) {
        console.error(`[${PLUGIN_NAME}] Failed to execute JS in activity frame:`, error);
        throw error;
    }
}
