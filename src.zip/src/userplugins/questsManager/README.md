# Quests Manager (Vencord UserPlugin)

Discord Quest Auto Completer — Vencord plugin built from the original console script.

## Requirements

Custom plugins only load when **Vencord is built from source** (not the installer-only build).

See: https://docs.vencord.dev/installing/custom-plugins/

**Launch Quest** (activity achievement) quests require the Discord **desktop** app with a source-built Vencord install. They use `native.ts` to run code inside the activity iframe (`*.discordsays.com`) and do not work in the browser extension or without rebuilding after adding `native.ts`.

## Install

1. Clone and set up Vencord from source if you have not already.
2. Create `src/userplugins` inside your Vencord folder (if it does not exist).
3. Copy this entire `questsManager` folder into:
   ```
   <Vencord>/src/userplugins/questsManager/
   ```
   You should end up with:
   ```
   <Vencord>/src/userplugins/questsManager/index.tsx
   <Vencord>/src/userplugins/questsManager/manager.ts
   <Vencord>/src/userplugins/questsManager/activityQuest.ts
   <Vencord>/src/userplugins/questsManager/native.ts
   <Vencord>/src/userplugins/questsManager/styles.css
   ```
4. Rebuild Vencord (from the Vencord repo root):
   ```
   pnpm build
   ```
   (or your usual Vencord build command)
5. Restart Discord completely.
6. Open **User Settings → Vencord → Plugins**, find **Quests Manager**, and enable it.
7. Open the **Quests** tab in Discord — a **Quests Manager** button appears in the Quests header.
8. Click the button to open the floating manager panel.

## Launch Quest workflow

Launch Quest (achievement-in-activity) quests work like Discord Quest Helper, with optional automation:

### Quick Start (recommended)

1. Click **Start** on the quest, then **Start Quest** in the dialog.
2. If the activity is not already open, Quests Manager will auto-launch it in Discord.
3. Complete any authorization prompts in Discord when they appear.
4. Wait up to ~90 seconds for the activity to load — checkpoints begin automatically.

### Manual path (same as Discord Quest Helper)

1. Click **Open in Discord** (or **Open Quest in Discord** in the launch dialog).
2. In Discord, click **Launch Quest** and complete authorization prompts.
3. Return to Quests Manager and click **Start**, then **Start Quest**.

Close any other open Discord activities before starting — the plugin only targets the activity iframe for this quest's application ID.

## Notes

- Disabling the plugin removes the button and closes/cleans up the panel.
- Closing the panel with ✕ only hides it; the plugin stays enabled and the Quests-tab button remains.
- Play / Stream quests need the Discord **desktop** app.
- Launch Quest (achievement-in-activity) quests need `native.ts` bundled in your Vencord build. If Start fails with a rebuild message, run `pnpm build` again and fully restart Discord.
